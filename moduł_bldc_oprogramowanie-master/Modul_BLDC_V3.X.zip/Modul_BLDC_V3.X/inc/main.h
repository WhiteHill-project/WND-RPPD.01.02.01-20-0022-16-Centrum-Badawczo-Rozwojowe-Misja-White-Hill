/* 
 * File:   main.h
 * Author: Jacek
 *
 * Created on 12 kwietnia 2018, 14:45
 */

#ifndef MAIN_H
#define	MAIN_H

#ifdef	__cplusplus
extern "C" {
#endif

	extern uint8_t myAddress;


#ifdef	__cplusplus
}
#endif

#endif	/* MAIN_H */

